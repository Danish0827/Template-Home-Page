export const DEFAULT_IMG_URL = 'https://via.placeholder.com/380x380';
