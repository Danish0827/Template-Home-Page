import Login from '@/components/Login/Login'
import React from 'react'

const login = () => {
  return (
    <>
      <Login/>
    </>
  )
}

export default login
