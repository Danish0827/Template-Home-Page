import React from "react";

import CheckOutMain from "@/components/CheckOut/CheckOutMain";

const checkouts = () => {
  return (
    <>
      <CheckOutMain />
    </>
  );
};

export default checkouts;
