import React from "react";
import Thank from "@/components/ThankYou/Thank";

const thankyou = () => {
  return (
    <>
      <Thank />
    </>
  );
};

export default thankyou;
