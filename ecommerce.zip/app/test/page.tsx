import React from 'react'
import Sliderv1 from "@/components/Sliders/SlidersV2/Slider";

const text = () => {
  return (
    <div>
      <Sliderv1/>
    </div>
  )
}

export default text
