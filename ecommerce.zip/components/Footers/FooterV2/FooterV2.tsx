'use client'
import React from "react";

const FooterV2 = () => {
  return <div>FooterV2</div>;
};

export default FooterV2;
