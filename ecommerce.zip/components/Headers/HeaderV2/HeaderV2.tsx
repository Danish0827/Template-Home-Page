import React from "react";

const HeaderV2 = () => {
  return <div>HeaderV2</div>;
};

export default HeaderV2;
